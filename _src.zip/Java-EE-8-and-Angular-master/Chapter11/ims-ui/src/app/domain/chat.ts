import { User } from "./user";

export class Chat {
    message: string;
    sender: User;
    created: Date;
}
