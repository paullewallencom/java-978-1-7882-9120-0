export class Credential {
    constructor(public username?: string, public password?: string) { }
}