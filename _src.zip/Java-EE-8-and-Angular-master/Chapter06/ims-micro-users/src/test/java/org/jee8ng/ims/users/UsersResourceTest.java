package org.jee8ng.ims.users;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.core.Response;
import org.junit.Test;

/**
 *
 * @author prashantp.org
 */
public class UsersResourceTest {

    @Test
    public void test() {
        
    }
}
