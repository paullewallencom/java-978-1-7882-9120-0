package org.jee8ng.jaxrsdemo;

import java.io.IOException;
import javax.ws.rs.client.ClientRequestContext;
import javax.ws.rs.client.ClientRequestFilter;

/**
 *
 * @author prashantp.org
 */
public class ClientRequestFilter1 implements ClientRequestFilter {

    @Override
    public void filter(ClientRequestContext requestContext) throws IOException {
        
    }    
    
}
