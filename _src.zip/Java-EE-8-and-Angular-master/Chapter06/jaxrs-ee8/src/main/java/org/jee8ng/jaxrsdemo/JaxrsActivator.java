package org.jee8ng.jaxrsdemo;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

/**
 *
 * @author prashantp.org
 */
@ApplicationPath("resources")
public class JaxrsActivator extends Application {
    
}
