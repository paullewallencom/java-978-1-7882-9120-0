export class User {
    constructor(public email: string, public phone: number, public name?: string) {} 
}