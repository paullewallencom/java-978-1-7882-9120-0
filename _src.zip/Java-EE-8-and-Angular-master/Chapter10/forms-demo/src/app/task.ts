export class Task {
    constructor(public title: string,
        public created: Date, public assigned?: string) { }
}
