package org.jee8ng.starter.cdise.annotationliteral;

/**
 * Simple POJO
 * 
 * @author prashantp.org
 */
public class ShopOrder {
    
}
