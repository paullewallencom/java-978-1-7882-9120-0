export class Statistics {
    bookings: number;
    cancellations: number;
    sales: number;
}
