package org.jee8ng.issuemanager.users;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroUsersApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroUsersApplication.class, args);
	}
}
