package org.jee8ng.ims.tasks;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

/**
 *
 * @author prashantp.org
 */
@ApplicationPath("resources")
public class JaxrsActivator extends Application {
    
}
