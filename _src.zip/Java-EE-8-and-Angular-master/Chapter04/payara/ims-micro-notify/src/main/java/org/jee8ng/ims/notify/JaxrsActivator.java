package org.jee8ng.ims.notify;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

/**
 *
 * @author prashantp.org
 */
@ApplicationPath("resources")
public class JaxrsActivator extends Application {
    
}
