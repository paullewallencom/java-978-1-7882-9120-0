package org.jee8ng.issuemanagerusers.rest;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

/**
 *
 * @author prashantp.org
 */
@ApplicationPath("rest")
public class JaxrsBootup extends Application {
    
}
