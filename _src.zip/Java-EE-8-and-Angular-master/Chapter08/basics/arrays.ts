let a: number[] = [1,2,3];
let b: Array<number> = [1,2,3];
let c: Array<any> = ['Hello',10];

let priorities = ['low', 'medium', 'high'];
let priorityUpperCase = priorities.map(p => p.toUpperCase());

