var a = [1, 2, 3];
var b = [1, 2, 3];
var c = ['Hello', 10];
var priorities = ['low', 'medium', 'high'];
var priorityUpperCase = priorities.map(function (p) { return p.toUpperCase(); });
